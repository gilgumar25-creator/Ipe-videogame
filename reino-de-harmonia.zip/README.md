# Reino de Harmonía · Fase 1

## Estructura
- `index.html`  Estructura de la interfaz (paneles, menús, mapa).
- `style.css`   Todo el aspecto visual. Colores y fuentes en las variables de `:root` (arriba del todo).
- `game.js`     Lógica. Busca estos bloques: `CFG`, `REG` (regiones), `MIS` (misiones y diálogos en formato JSON editable), `MODELOS`.
- `modelos/`    Tus archivos .glb (opcional).

## Ejecutar
Sin modelos: doble clic en `index.html`.
Con modelos: abre una terminal en esta carpeta y ejecuta `python3 -m http.server 8000`, luego entra en http://localhost:8000
(abriendo el archivo directamente, el navegador bloquea la carga de .glb).

## Usar personajes 3D más realistas
1. Descarga un personaje en .glb con esqueleto y animaciones (Mixamo, Quaternius, Kenney, Sketchfab; revisa la licencia).
2. Guárdalo en `modelos/` y en `game.js` edita `MODELOS`: `jugador:'modelos/heroe.glb'`, `npc:'modelos/aldeano.glb'`.
3. Ajusta `escala` si sale muy grande o pequeño y `anim` con los nombres reales de las animaciones (se ven en la consola del navegador o en gltf.report).
4. Si quieres que cambien de color con el editor, nombra los materiales `pelo`, `ropa` y `piel` en Blender.
Si el archivo falla, el juego sigue usando el personaje low-poly.

## Añadir una misión
Copia un objeto de `MIS` en `game.js`: cada paso (`steps`) tiene un texto (`say`) y opciones (`opts`) con puntos por competencia (`p:{eq,ie,co,gc,ot}`) y consejo (`fb`). Después añade un personaje en la lista `NPC` con `m:` igual al id de la misión.
