/* Reino de Harmonía · lógica del juego. Secciones: DATOS (misiones, regiones) · ESTADO · AUDIO · ESCENA · MODELOS · MUNDO · JUGADOR · UI · DIÁLOGOS · MAPA · BUCLE */
/* ===== DATOS (editables) ===== */
const $=s=>document.querySelector(s),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const CFG={target:12,unlockTower:60}; // puntos de competencia para el 100 % de una región (Fase 3: fórmula por misiones ponderadas)
const COMP={eq:'Trabajo en equipo',ie:'Inteligencia emocional',co:'Técnicas de comunicación',gc:'Gestión del conflicto',ot:'Organización y gestión del tiempo'};
const REG=[
{id:'forja',n:'La Forja de la Concordia',c:'eq',x:170,y:165,col:'#7a4a38',d:'Volcanes, engranajes y fraguas: expediciones en grupo y reparto de tareas.'},
{id:'torre',n:'La Torre de la Resonancia',c:'co',x:500,y:100,col:'#5a86b8',d:'Torre de cristal e islas flotantes: escucha activa, negociación y pergaminos.'},
{id:'oasis',n:'El Oasis de la Empatía',c:'ie',x:830,y:185,col:'#d8b86a',d:'Personas desbordadas por el miedo, la ira o la tristeza. Tu respuesta cambia el clima.'},
{id:'cruce',n:'La Encrucijada de los Tratos',c:'gc',x:815,y:410,col:'#a35a8a',d:'Mercado de puentes y dirigibles: facciones enfrentadas, mediación y acuerdos.'},
{id:'chronos',n:'Val Chronos',c:'ot',x:185,y:410,col:'#3f8f78',d:'Bosque de relojes: plazos, tareas simultáneas y recursos escasos.'}];
const MIS=[
{id:'m1',t:'Entrevista en el Gremio',xp:45,coins:15,after:'¡Bienvenido/a, aprendiz! Y recuerda: el gremio contrata personas, no currículums.',steps:[
 {say:'Siéntate, que no muerdo (mucho). ¿Por qué quieres formar parte del Gremio?',opts:[
  {t:'Necesito monedas, no te voy a mentir.',p:{co:1},fb:'Sincero está bien, pero cuéntales también qué aportas tú.'},
  {t:'Aprendo rápido y me gusta el trabajo en equipo. Por ejemplo, en mi última expedición reorganicé los turnos de guardia.',p:{co:3,eq:1},fb:'Un ejemplo concreto pesa más que diez adjetivos.'},
  {t:'Eh... ¿y usted por qué trabaja aquí?',p:{ie:1},fb:'Devolver la pregunta muestra curiosidad, pero antes responde tú: si no, suena a evasiva.'}]},
 {say:'Un compañero critica tu trabajo delante de todos. ¿Qué haces?',opts:[
  {t:'Respiro, le pido que concrete qué mejorar y lo hablamos luego a solas.',p:{ie:3,gc:1},fb:'Pausa emocional + pedir datos: gestionas lo que sientes sin esconderlo.'},
  {t:'Le respondo al momento: ¡su trabajo tampoco es perfecto!',p:{},fb:'Se entiende la rabia, pero responder en caliente suele escalar el conflicto. Prueba a contar hasta diez.'},
  {t:'Me callo y me lo guardo.',p:{ie:1},fb:'Callar evita el choque hoy, pero la bola crece. Hablarlo con calma es más sano.'}]}]},
{id:'m2',t:'Dos yunques, una fragua',xp:50,coins:20,after:'Brisa y Torvik se turnan... ¡y hasta cantan juntos! Ni yo me lo creo.',steps:[
 {say:'Brisa grita «¡Es mío!» y Torvik «¡Llevo aquí desde el alba!». Me espantan la clientela. ¿Cómo empiezas a mediar?',opts:[
  {t:'Pido que cada uno cuente su versión sin interrumpir y resumo lo que oigo.',p:{gc:3,co:2},fb:'Escucha activa + resumen: bajan las revoluciones y ambos se sienten oídos.'},
  {t:'Doy la razón a Torvik, parece más tranquilo.',p:{},fb:'Tomar partido por simpatía rompe la confianza de la otra parte. Un mediador es neutral.'},
  {t:'Decido yo quién se queda el yunque.',p:{gc:1},fb:'Resuelve rápido, pero impone: sin acuerdo propio el conflicto reaparece.'}]},
 {say:'Los dos necesitan el yunque. ¿Qué propones?',opts:[
  {t:'Turnos de mañana y tarde, y que ambos lo acepten en voz alta.',p:{gc:3,ot:1,eq:1},fb:'Acuerdo concreto, aceptado por ambas partes: la mejor salida.'},
  {t:'Que se lo repartan 50/50... partiendo el yunque.',p:{gc:1},fb:'Ingenioso, pero impracticable. Busca intereses comunes, no mitades literales.'},
  {t:'Que se vayan a casa a calmarse.',p:{ie:1},fb:'Calmarse ayuda, pero sin acuerdo volverán a pelear mañana.'}]}]},
{id:'m3',t:'Entrega antes del atardecer',xp:50,coins:20,after:'Todo entregado y sin sudar. Yo también quiero tu agenda.',steps:[
 {say:'¡Socorro! Tres encargos y el sol se va: carta urgente al Banco, caja frágil a la taberna y un pergamino para mañana. ¡Decide ya!',time:12,to:'Se acabó el tiempo y decidió el azar. Decidir tarde también es decidir: priorizar a tiempo es parte del trabajo.',opts:[
  {t:'Ordeno por urgencia e importancia: carta, caja y pergamino al final.',p:{ot:3},fb:'Priorizar con un criterio claro es la base de la gestión del tiempo.'},
  {t:'Empiezo por lo más fácil para sentirme productivo.',p:{ot:1},fb:'Da energía, pero deja lo urgente para el final. Ojo a ese sesgo.'},
  {t:'Salgo corriendo con los tres a la vez.',p:{},fb:'La multitarea suele romper la caja frágil. Una cosa cada vez.'}]},
 {say:'Vas a llegar tarde a una entrega. ¿Qué haces?',opts:[
  {t:'Aviso ya al destinatario y propongo una hora nueva.',p:{co:2,ot:2},fb:'Avisar pronto y con alternativa convierte un fallo en confianza.'},
  {t:'Pido ayuda a otra persona para repartir la carga.',p:{eq:3},fb:'Pedir ayuda a tiempo no es debilidad: es trabajar en equipo.'},
  {t:'Me callo y rezo para que nadie se dé cuenta.',p:{},fb:'Esconder el retraso suele salir caro. Comunicarlo cuanto antes casi siempre sale mejor.'}]}]}];
/* ===== ESTADO / GUARDADO ===== */
const KEY='harmonia_v1';
const S={name:'',cols:['#e9b949','#3b6fd8','#f2c8a0'],acc:0,lvl:1,xp:0,coins:20,comp:{eq:0,ie:0,co:0,gc:0,ot:0},done:{},active:null};
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
function load(){try{const d=JSON.parse(localStorage.getItem(KEY));if(d&&d.comp){Object.assign(S,d);return true}}catch(e){}return false}
const pct=c=>clamp(Math.round(S.comp[c]/CFG.target*100),0,100),dom=p=>p<34?['Inicial','#e0a040']:p<67?['Medio','#40b8d8']:['Avanzado','#6adf7a'];
/* ===== AUDIO ===== */
let AC,mute=false;
function au(){if(AC){AC.state=='suspended'&&AC.resume();return}try{AC=new(window.AudioContext||window.webkitAudioContext)();setInterval(()=>{const P=[261.6,293.7,329.6,392,440,523.2];tone(P[Math.random()*6|0],1.8,.03,'triangle');Math.random()<.5&&tone(P[Math.random()*6|0]/2,2.2,.025)},1900)}catch(e){}}
function tone(f,d=.15,v=.05,ty='sine'){if(!AC||mute)return;const o=AC.createOscillator(),g=AC.createGain();o.type=ty;o.frequency.value=f;g.gain.setValueAtTime(v,AC.currentTime);g.gain.exponentialRampToValueAtTime(.0001,AC.currentTime+d);o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}
/* ===== ESCENA ===== */
const R=new THREE.WebGLRenderer({canvas:$('#g'),antialias:true}),sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(60,1,.1,300);
R.shadowMap.enabled=true;R.shadowMap.type=THREE.PCFSoftShadowMap;
function rs(){R.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}addEventListener('resize',rs);
const hemi=new THREE.HemisphereLight(0xcfe8ff,0x4a6a3a,.7),sun=new THREE.DirectionalLight(0xfff0d0,1);
sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-35,right:35,top:35,bottom:-35,near:1,far:150});sc.add(hemi,sun,sun.target);sc.fog=new THREE.Fog(0x9ad0f0,45,130);
const mat=c=>new THREE.MeshStandardMaterial({color:c,flatShading:true,roughness:1});
function mk(g,c,x=0,y=0,z=0,par=sc){const m=new THREE.Mesh(g,mat(c));m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;par.add(m);return m}
function lab(t,col='#fff',w=4){const c=document.createElement('canvas');c.width=256;c.height=64;const x=c.getContext('2d');x.font='bold 26px Georgia';x.textAlign='center';x.fillStyle='#0009';x.fillRect(0,12,256,40);x.fillStyle=col;x.fillText(t,128,42);const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true}));s.scale.set(w,w/4,1);return s}
function person(c,a){const g=new THREE.Group(),B=THREE.BoxGeometry;
 mk(new THREE.CylinderGeometry(.35,.45,.9,7),c[1],0,.95,0,g);mk(new THREE.SphereGeometry(.32,8,6),c[2],0,1.75,0,g);mk(new THREE.SphereGeometry(.34,8,5,0,6.3,0,1.3),c[0],0,1.78,0,g);
 g.legs=[mk(new B(.22,.6,.25),'#3a3a55',-.18,.3,0,g),mk(new B(.22,.6,.25),'#3a3a55',.18,.3,0,g)];
 if(a==1)mk(new THREE.ConeGeometry(.5,.6,7),c[0],0,2.2,0,g);if(a==2)mk(new B(.8,1.1,.08),c[0],0,1.1,-.4,g);return g}
/* ===== MODELOS 3D (OPCIONAL) =====
 Para usar personajes .glb: pon los archivos en /modelos y escribe aquí su ruta (necesitas servidor local, ver README).
 null = se usa el personaje low-poly generado por código.
 Materiales del modelo llamados "pelo", "ropa" y "piel" se tiñen con los colores del editor.
 Nombres de animación: ajusta "anim" a los nombres reales de tu archivo. */
const MODELOS={jugador:null,npc:null,escala:1,anim:{idle:'Idle',walk:'Walk',run:'Run'}};
const GLTF=THREE.GLTFLoader?new THREE.GLTFLoader():null,MIX=[];
function cargarModelo(url,cb){if(!GLTF)return;GLTF.load(url,g=>{const m=g.scene,w=new THREE.Group();m.scale.setScalar(MODELOS.escala);m.traverse(o=>{if(o.isMesh)o.castShadow=o.receiveShadow=true});w.add(m);w.legs=[{rotation:{}},{rotation:{}}];
 if(g.animations.length){const mx=new THREE.AnimationMixer(m);w.acts={};g.animations.forEach(a=>w.acts[a.name]=mx.clipAction(a));MIX.push(mx);animar(w,'idle')}cb(w)},undefined,e=>console.warn('No se pudo cargar',url,e))}
function tinte(g,c=S.cols){g.traverse(o=>{if(o.isMesh&&o.material&&o.material.name){const i=['pelo','ropa','piel'].indexOf(o.material.name.toLowerCase());if(i>=0)o.material.color.set(c[i])}})}
function animar(p,n){if(!p.acts)return;const a=p.acts[MODELOS.anim[n]]||p.acts[MODELOS.anim.walk];if(!a||p.cur===a)return;p.cur&&p.cur.fadeOut(.2);a.reset().fadeIn(.2).play();p.cur=a}
/* ===== MUNDO: Ciudad del Gremio ===== */
const COL=[],IT=[],GATES=[];
mk(new THREE.CylinderGeometry(70,70,1,28),'#5f9a52',0,-.5,0);mk(new THREE.CylinderGeometry(15,15,.3,24),'#b4b0a4',0,.05,0);
mk(new THREE.CylinderGeometry(3,3.2,.8,14),'#9a9aa8',0,.4,0);mk(new THREE.CylinderGeometry(2.5,2.5,.9,14),'#4fc3e8',0,.45,0);mk(new THREE.CylinderGeometry(.3,.3,2.2,6),'#9a9aa8',0,1.2,0);COL.push({x:0,z:0,r:3.2});
function house(x,z,w,h,wc,rc,name,msg){mk(new THREE.BoxGeometry(w,h,w),wc,x,h/2,z);const r=mk(new THREE.ConeGeometry(w*.85,h*.6,4),rc,x,h+h*.3,z);r.rotation.y=Math.PI/4;const l=lab(name);l.position.set(x,h*1.75,z);sc.add(l);COL.push({x,z,r:w/2+.8});IT.push({x,z:z+w/2+1,n:name,act:()=>tip(name,msg())})}
house(-22,-9,7,4.5,'#d9a066','#a8432e','Taberna',()=>'Aquí se formará tu grupo de aventureros (Fase 2). Invita la casa... a medias.');
house(22,-9,7,4.5,'#c9c2b0','#3f5a8a','Banco',()=>`Tienes ${S.coins} monedas. Los intereses son de risa, pero seguros.`);
house(22,14,7,4.5,'#b9a0d8','#6a3a8a','Entrenador',()=>'Los talentos y habilidades llegan en la Fase 2. Calentando motores.');
house(-22,14,7,4.5,'#e0d090','#2e8a6a','Gran Salón',()=>'El puesto en el Gremio Mayor se gana en la Torre del Primer Empleo (Fase 4).');
mk(new THREE.BoxGeometry(5,2.4,.3),'#7a5a3a',0,2,-19);mk(new THREE.BoxGeometry(.3,2.4,.3),'#4a3a22',-2.5,1.2,-19);mk(new THREE.BoxGeometry(.3,2.4,.3),'#4a3a22',2.5,1.2,-19);
{const l=lab('Tablón de misiones');l.position.set(0,3.6,-19);sc.add(l);COL.push({x:0,z:-19,r:3});IT.push({x:0,z:-17,n:'Tablón de misiones',act:()=>tip('Tablón','Misiones: «Entrevista» (Ilvara), «Dos yunques» (Moka) y «Entrega» (Pip). Busca la «!» dorada.')})}
REG.forEach(r=>{const a=Math.atan2(r.y-290,r.x-500),x=Math.cos(a)*46,z=Math.sin(a)*46,g=new THREE.Group();g.position.set(x,0,z);sc.add(g);
 mk(new THREE.BoxGeometry(.8,5,.8),'#8a8478',-2.5,2.5,0,g);mk(new THREE.BoxGeometry(.8,5,.8),'#8a8478',2.5,2.5,0,g);mk(new THREE.BoxGeometry(6,.8,.9),'#8a8478',0,5.2,0,g);
 const cr=mk(new THREE.IcosahedronGeometry(.9),r.col,0,3,0,g);cr.material.emissive=new THREE.Color(r.col);cr.material.emissiveIntensity=.7;g.cr=cr;g.rotation.y=-a+Math.PI/2;
 const l=lab(r.n,'#ffe9a0',6);l.position.set(x,7.4,z);sc.add(l);GATES.push({x,z,col:r.col,g});COL.push({x:x-2.5,z,r:1},{x:x+2.5,z,r:1});IT.push({x,z,n:r.n,act:()=>tip(r.n,'Esta región se abre en la Fase 3. Tu progreso en «'+COMP[r.c]+'» ya cuenta en el mapa.')})});
for(let i=0;i<75;i++){const a=Math.random()*6.28,d=24+Math.random()*42,x=Math.cos(a)*d,z=Math.sin(a)*d;if(GATES.some(g=>Math.hypot(g.x-x,g.z-z)<8))continue;mk(new THREE.CylinderGeometry(.2,.3,1.4,5),'#6a4a2a',x,.7,z);mk(new THREE.ConeGeometry(1.4,2.2,6),i%3?'#2f8a4a':'#3fa05a',x,2.3,z);mk(new THREE.ConeGeometry(1,1.7,6),'#46b060',x,3.5,z)}
const FF=new THREE.Points(new THREE.BufferGeometry().setAttribute('position',new THREE.BufferAttribute(new Float32Array(Array.from({length:360},(_,i)=>i%3==1?.5+Math.random()*6:(Math.random()-.5)*110)),3)),new THREE.PointsMaterial({size:.3,color:0xffe27a}));sc.add(FF);
const NPC=[{n:'Maestra Ilvara',m:'m1',x:0,z:-12,c:['#8a5cd6','#6a3fa0','#e8b88a'],a:1},{n:'Moka la Tabernera',m:'m2',x:-14,z:1,c:['#c24a2e','#d8a33c','#c68a5c'],a:0},{n:'Pip el Mensajero',m:'m3',x:12,z:7,c:['#2e9e8a','#e0c040','#f0c8a0'],a:2}];
NPC.forEach(n=>{n.o=person(n.c,n.a);n.o.position.set(n.x,0,n.z);sc.add(n.o);MODELOS.npc&&cargarModelo(MODELOS.npc,g=>{sc.remove(n.o);g.position.copy(n.o.position);n.o=g;sc.add(g);tinte(g,n.c)});const l=lab(n.n,'#ffe9a0');l.position.set(n.x,2.9,n.z);sc.add(l);n.mk=lab('!','#ffd84a',1.6);n.mk.position.set(n.x,3.8,n.z);sc.add(n.mk);COL.push({x:n.x,z:n.z,r:.8});IT.push({x:n.x,z:n.z,n:n.n,act:()=>talk(n)})});
[[-10,9,'#d07a5a',1,'Brisa'],[-7.6,9,'#5a7ad0',-1,'Torvik']].forEach(([x,z,c,s,n])=>{const o=person([c,c,'#e0b090'],0);o.position.set(x,0,z);o.rotation.y=s*1.57;sc.add(o);const l=lab(n);l.position.set(x,2.9,z);sc.add(l)});
/* ===== JUGADOR / CÁMARA ===== */
let P,started=false,ui=null,yaw=0,pit=.35,dist=9,vy=0,walk=0,en=100,drag=false,T=.25,D=null;const k={};
let pid=0;function poner(g,pos){P&&sc.remove(P);P=g;P.position.copy(pos);sc.add(P)}
function setP(){const pos=P?P.position.clone():new THREE.Vector3(0,0,9),id=++pid;poner(person(S.cols,S.acc),pos);
 if(MODELOS.jugador)cargarModelo(MODELOS.jugador,g=>{if(id==pid){poner(g,P.position.clone());tinte(g)}})}
function sync(){S.cols=[$('#c0').value,$('#c1').value,$('#c2').value];S.acc=+$('#ac').value;setP()}
['c0','c1','c2','ac'].forEach(i=>$('#'+i).oninput=sync);
addEventListener('pointerdown',e=>{au();if(e.target.id=='g')drag=true});addEventListener('pointerup',()=>drag=false);
addEventListener('pointermove',e=>{if(drag&&started&&!ui){yaw-=e.movementX*.006;pit=clamp(pit+e.movementY*.005,.05,1.2)}});
addEventListener('wheel',e=>{if(started&&!ui)dist=clamp(dist+e.deltaY*.01,4,16)},{passive:true});
addEventListener('keyup',e=>k[e.code]=0);
addEventListener('keydown',e=>{if(!started)return;au();k[e.code]=1;const c=e.code;
 if(c=='Space'||c.startsWith('Arrow'))e.preventDefault();
 if(c=='KeyM')tg('map');else if(c=='KeyJ'||c=='KeyB')tg('jr');else if(c=='Escape')closeAll();
 else if(c=='KeyE'&&!ui)near()&&near().act();else if(c=='Space'&&!ui&&P.position.y<=.01)vy=8});
function near(){let b=null,bd=3.8;IT.forEach(i=>{const d=Math.hypot(i.x-P.position.x,i.z-P.position.z);if(d<bd){bd=d;b=i}});return b}
/* ===== UI ===== */
function say(w,t,col='#ffe9a0'){const c=$('#chat'),d=document.createElement('div');d.innerHTML=`<b style="color:${col}">${w}:</b> ${t}`;c.appendChild(d);c.scrollTop=1e5}
let ttm;function tip(n,t){say(n,t);const e=$('#tt');e.textContent=t;e.style.display='block';clearTimeout(ttm);ttm=setTimeout(()=>e.style.display='none',3800)}
function hud(){$('#pn').textContent=S.name;$('#pp').textContent=S.name[0]||'?';$('#pp').style.background='radial-gradient(circle at 35% 30%,'+S.cols[2]+','+S.cols[1]+')';$('#pl').textContent=S.lvl;$('#xb').style.width=100*S.xp/need()+'%';const m=MIS.find(x=>x.id==S.active);$('#qt').innerHTML='<b style="color:var(--gold)">Misión</b><br>'+(m?m.t:'Habla con quien tenga una «!» dorada sobre la cabeza.')}
const need=()=>60+S.lvl*20;
function closeAll(){['#map','#jr','#dlg'].forEach(s=>$(s).style.display='none');if(ui=='dlg'){D=null;S.active=null;hud()}ui=null}
function tg(w){const was=ui;closeAll();if(was==w)return;ui=w;if(w=='map'){drawMap();$('#map').style.display='block'}else{journal();$('#jr').style.display='block'}}
$('#bm').onclick=()=>tg('map');$('#bj').onclick=()=>tg('jr');
$('#bs').onclick=e=>{mute=!mute;e.target.textContent='Sonido: '+(mute?'no':'sí')};
const QL=[['Alta',2,1],['Media',1,1],['Baja',.75,0]];let ql=0;
$('#bq').onclick=e=>{ql=(ql+1)%3;const[n,pr,sh]=QL[ql];R.setPixelRatio(pr*Math.min(devicePixelRatio,2)/ (pr>1?2:1));sun.castShadow=!!sh;e.target.textContent='Calidad: '+n;rs()};
function journal(){let h='<h2>Diario de '+S.name+'</h2><p>Monedas: '+S.coins+' · Nivel '+S.lvl+' · XP '+S.xp+'/'+need()+'</p><h3>Misiones</h3>';
 MIS.forEach(m=>h+=`<p>${S.done[m.id]?'✅':m.id==S.active?'⏳':'⬜'} ${m.t}</p>`);h+='<h3>Tus competencias</h3>';
 Object.keys(COMP).forEach(c=>{const p=pct(c),[l,col]=dom(p);h+=`<div class="cb">${COMP[c]} — <b style="color:${col}">${l}</b> (${p}%)<div class="bar"><i style="width:${p}%;background:${col}"></i></div></div>`});
 $('#jr').innerHTML=h+'<p><button onclick="closeAll()">Cerrar</button></p>'}
/* ===== DIÁLOGOS Y MISIONES ===== */
function dlg(name,txt,btns,tm,cls=''){ui='dlg';$('#dlg').style.display='block';$('#dn').textContent=name;$('#dt').textContent=txt;$('#dt').className=cls;const b=$('#db');b.innerHTML='';btns.forEach(([t,f])=>{const e=document.createElement('button');e.textContent=t;e.onclick=()=>{au();tone(520,.12);f()};b.appendChild(e)});$('#tm').style.display=tm?'block':'none'}
function talk(n){const m=MIS.find(x=>x.id==n.m);if(S.done[m.id])return dlg(n.n,m.after,[['Cerrar',closeAll]]);D={m,n,i:0,acc:{},t:0};S.active=m.id;hud();step()}
function step(){const st=D.m.steps[D.i];D.t=st.time||0;D.T=D.t;dlg(D.n.n,st.say,st.opts.map((o,k)=>[o.t,()=>pick(k)]),st.time)}
function pick(k){const st=D.m.steps[D.i],o=k<0?{p:{},fb:st.to}:st.opts[k];D.t=0;for(const c in o.p)D.acc[c]=(D.acc[c]||0)+o.p[c];
 say('Mentora Ilvara',o.fb,'#6adf7a');dlg('Consejo de la mentora',o.fb,[['Continuar',()=>{D.i++;D.i<D.m.steps.length?step():finish()}]],0,'fb')}
function finish(){const m=D.m,ks=Object.keys(D.acc).filter(c=>D.acc[c]>0);for(const c in D.acc)S.comp[c]+=D.acc[c];S.done[m.id]=1;S.active=null;S.coins+=m.coins;S.xp+=m.xp;let lv='';
 while(S.xp>=need()){S.xp-=need();S.lvl++;lv=' ¡Subes al nivel '+S.lvl+'!'}
 const g=ks.length?'Has crecido en: '+ks.map(c=>COMP[c]).join(', ')+'.':'Esta vez no sumas competencias, pero ya sabes qué probar.';
 say('Sistema',`«${m.t}» completada. +${m.xp} XP, +${m.coins} monedas.${lv} ${g}`,'#e9b949');tone(660,.2,.06);setTimeout(()=>tone(880,.3,.06),150);D=null;save();hud();dlg('Misión completada',`${m.t}: +${m.xp} XP, +${m.coins} monedas.${lv} ${g}`,[['Cerrar',closeAll]])}
/* ===== MAPA ===== */
let zoom=1;function setZ(z){zoom=clamp(z,1,2.5);const w=1000/zoom,h=580/zoom;$('#sv').setAttribute('viewBox',`${500-w/2} ${290-h/2} ${w} ${h}`)}
$('#zi').onclick=()=>setZ(zoom+.3);$('#zo').onclick=()=>setZ(zoom-.3);$('#sv').addEventListener('wheel',e=>{e.preventDefault();setZ(zoom-Math.sign(e.deltaY)*.2)},{passive:false});
document.querySelectorAll('#mb button').forEach(b=>b.onclick=()=>{const a=b.dataset.a;if(a=='jr')tg('jr');else if(a=='back')closeAll();else if(a!='map')tip('Sistema','Talentos y equipo llegan en la Fase 2.')});
const MOT={forja:'<polygon points="-70,25 -35,-45 0,25" fill="#4a3a3a"/><polygon points="-20,25 20,-25 60,25" fill="#5a4a46"/><circle cx="-35" cy="-45" r="7" fill="#ff7a2a"/><circle cx="38" cy="-2" r="22" fill="none" stroke="#c99a4a" stroke-width="8" stroke-dasharray="7 5"/>',
torre:'<polygon points="0,-62 16,-15 0,28 -16,-15" fill="#8fe8ff" stroke="#fff" stroke-width="2"/><ellipse cy="-18" rx="62" ry="12" fill="none" stroke="#bff" stroke-dasharray="4 5"/>',
oasis:'<ellipse cx="-10" cy="12" rx="45" ry="18" fill="#4fd0e0"/><rect x="25" y="-38" width="14" height="48" fill="#cff"/><rect x="-62" y="-25" width="5" height="35" fill="#6b4a2a"/><circle cx="-59" cy="-30" r="16" fill="#3a9a4a"/>',
cruce:'<polygon points="-60,22 -40,-12 -20,22" fill="#e0504a"/><polygon points="-15,22 5,-18 25,22" fill="#e0b040"/><polygon points="30,22 50,-10 70,22" fill="#5a8ae0"/><ellipse cy="-45" rx="28" ry="10" fill="#c9a870"/>',
chronos:'<circle cx="-25" cy="0" r="32" fill="#e9d9a0" stroke="#8a6a2a" stroke-width="5"/><path d="M-25 0V-20M-25 0L-10 8" stroke="#333" stroke-width="3"/><circle cx="42" cy="-5" r="20" fill="#2a6ab0"/><circle cx="55" cy="15" r="14" fill="#2a6ab0"/>'};
function drawMap(){const m=MIS.find(x=>x.id==S.active),avail=MIS.filter(x=>!S.done[x.id]).length,av=Math.round(Object.keys(COMP).reduce((s,c)=>s+pct(c),0)/5);
 $('#mtop').innerHTML=`<span>Nivel: <b>${S.lvl}</b></span><span>Monedas: <b>${S.coins}</b></span><span>Misión activa: <b>${m?m.t:'—'}</b></span>`;
 let h='<defs><radialGradient id="sea" cx=".5" cy=".5" r=".75"><stop offset="0" stop-color="#3a9ad0"/><stop offset="1" stop-color="#14386a"/></radialGradient></defs><rect x="-300" y="-300" width="1600" height="1200" fill="url(#sea)"/>';
 REG.forEach(r=>h+=`<line x1="500" y1="290" x2="${r.x}" y2="${r.y}" stroke="#8a6a3a" stroke-width="8" stroke-dasharray="14 6"/>`);h+='<line x1="500" y1="290" x2="500" y2="505" stroke="#8a6a3a" stroke-width="8" stroke-dasharray="14 6"/>';
 REG.forEach(r=>{const p=pct(r.c),[l,col]=dom(p);h+=`<g class="rg" data-id="${r.id}" transform="translate(${r.x},${r.y})"><ellipse rx="135" ry="72" fill="${r.col}" stroke="#fff5" stroke-width="3"/>${MOT[r.id]}
 <text y="92" text-anchor="middle" fill="#ffe9a0" font-size="17" font-weight="bold" font-family="Georgia">${r.n}</text><text y="108" text-anchor="middle" fill="#fff" font-size="12" font-family="Georgia">${COMP[r.c]}</text>
 <rect x="-80" y="114" width="150" height="10" rx="5" fill="#0009"/><rect x="-80" y="114" width="${1.5*p}" height="10" rx="5" fill="${col}"/><text x="76" y="123" fill="#fff" font-size="12" font-family="Georgia">${p}%</text></g>`});
 const tow=av>=CFG.unlockTower&&Object.keys(COMP).every(c=>pct(c)>=CFG.unlockTower);
 h+=`<g class="rg" data-id="tower" transform="translate(500,505)"><ellipse rx="70" ry="30" fill="#4a4a5a" stroke="#fff5" stroke-width="3"/><polygon points="-14,10 -10,-40 10,-40 14,10" fill="#8a8aa0"/><text y="-48" text-anchor="middle" font-size="20">${tow?'🏰':'🔒'}</text><text y="52" text-anchor="middle" fill="#ffe9a0" font-size="14" font-family="Georgia">Torre del Primer Empleo</text></g>`;
 h+=`<g class="rg" data-id="city" transform="translate(500,290)"><circle r="75" fill="#8fb35a" stroke="#fff5" stroke-width="3"/><rect x="-45" y="-25" width="28" height="22" fill="#d9a066"/><polygon points="-48,-25 -31,-42 -14,-25" fill="#a8432e"/><rect x="10" y="-15" width="30" height="24" fill="#c9c2b0"/><polygon points="7,-15 25,-34 43,-15" fill="#3f5a8a"/><circle cy="22" r="9" fill="#4fc3e8"/>
 <text y="95" text-anchor="middle" fill="#ffe9a0" font-size="17" font-weight="bold" font-family="Georgia">Ciudad del Gremio</text><circle cx="-55" cy="-45" r="9" fill="#fff"><animate attributeName="r" values="7;13;7" dur="1.6s" repeatCount="indefinite"/></circle><text x="-55" y="-41" text-anchor="middle" font-size="12">📍</text>
 ${avail?'<text x="58" y="-40" fill="#ffd84a" font-size="30" font-weight="bold">!</text>':''}</g>`;
 $('#sv').innerHTML=h;setZ(zoom);document.querySelectorAll('.rg').forEach(g=>{g.onmouseenter=g.onclick=()=>info(g.dataset.id)});info('city')}
function info(id){const mp=$('#mp');let h='',b='';
 if(id=='city'){const n=MIS.find(x=>!S.done[x.id]);h=`<h3>Ciudad del Gremio</h3>Tu punto de partida: taberna, banco, tablón y entrenador.<br>Misiones: ${Object.keys(S.done).length}/${MIS.length}<br>Siguiente: ${n?n.t:'¡todas hechas!'}`;b='<br><button id="vj" style="margin-top:6px">Viaje rápido a la plaza</button>'}
 else if(id=='tower'){h='<h3>Torre del Primer Empleo</h3>Se desbloquea al llegar al '+CFG.unlockTower+'% en las 5 competencias.<br>Requisitos pendientes: '+Object.keys(COMP).filter(c=>pct(c)<CFG.unlockTower).map(c=>COMP[c]).join(', ')}
 else{const r=REG.find(x=>x.id==id),p=pct(r.c),[l]=dom(p);h=`<h3>${r.n}</h3>${r.d}<br>Dominio: <b>${l}</b> (${p}%)<br><i>Zona jugable en la Fase 3; tu progreso ya cuenta.</i>`;b='<br><button disabled style="margin-top:6px">Viaje rápido (Fase 3)</button>'}
 mp.innerHTML=h+b;const v=$('#vj');if(v)v.onclick=()=>{P.position.set(0,0,9);closeAll()}}
/* ===== BUCLE ===== */
const mc=$('#mc').getContext('2d');
function mini(){const x=mc;x.clearRect(0,0,130,130);x.save();x.beginPath();x.arc(65,65,64,0,7);x.clip();x.fillStyle='#2f5f3a';x.fillRect(0,0,130,130);const s=65/70,X=v=>65+v*s;
 x.fillStyle='#9a9aa8';x.beginPath();x.arc(65,65,15*s,0,7);x.fill();GATES.forEach(g=>{x.fillStyle=g.col;x.fillRect(X(g.x)-3,X(g.z)-3,6,6)});
 NPC.forEach(n=>{if(!S.done[n.m]){x.fillStyle='#ffd84a';x.fillRect(X(n.x)-2,X(n.z)-2,4,4)}});
 x.translate(X(P.position.x),X(P.position.z));x.rotate(Math.PI-P.rotation.y);x.fillStyle='#fff';x.beginPath();x.moveTo(0,-6);x.lineTo(4,5);x.lineTo(-4,5);x.fill();x.restore()}
let last=performance.now();
function loop(t){requestAnimationFrame(loop);const dt=Math.min((t-last)/1000,.05);last=t;
 T=(T+dt/120)%1;const day=clamp(Math.sin(T*6.283)*1.4+.5,0,1),sk=new THREE.Color(0x0e1438).lerp(new THREE.Color(0x9ad0f0),day);sc.background=sk;sc.fog.color=sk;sun.intensity=.15+.95*day;hemi.intensity=.25+.5*day;
 MIX.forEach(m=>m.update(dt));FF.rotation.y+=dt*.02;FF.material.opacity=1;GATES.forEach(g=>g.g.cr.rotation.y+=dt);NPC.forEach(n=>{n.mk.visible=!S.done[n.m]});
 if(!started){yaw+=dt*.3;pit=.2;dist=7}
 else if(!ui||ui=='dlg'){if(ui!='dlg')move(dt);else if(D&&D.t>0){D.t-=dt;$('#tm').style.width=100*Math.max(D.t,0)/D.T+'%';if(D.t<=0)pick(-1)}}
 const tx=P.position.x,ty=P.position.y+1.6,tz=P.position.z;cam.position.set(tx+Math.sin(yaw)*Math.cos(pit)*dist,Math.max(.6,ty+Math.sin(pit)*dist),tz+Math.cos(yaw)*Math.cos(pit)*dist);cam.lookAt(tx,ty,tz);
 sun.position.set(tx+30,50*Math.max(day,.3),tz+20);sun.target.position.set(tx,0,tz);
 NPC.forEach(n=>{if(Math.hypot(n.x-tx,n.z-tz)<8)n.o.rotation.y=Math.atan2(tx-n.x,tz-n.z)});
 if(started){const b=near(),h=$('#hint');if(b&&!ui){h.style.display='block';h.textContent='E · '+b.n}else h.style.display='none';$('#eb').style.width=en+'%';mini()}
 R.render(sc,cam)}
function move(dt){const f=(k.KeyW||k.ArrowUp?1:0)-(k.KeyS||k.ArrowDown?1:0),r=(k.KeyD||k.ArrowRight?1:0)-(k.KeyA||k.ArrowLeft?1:0),run=k.ShiftLeft&&en>5&&(f||r),p=P.position;
 if(f||r){let mx=-Math.sin(yaw)*f+Math.cos(yaw)*r,mz=-Math.cos(yaw)*f-Math.sin(yaw)*r;const l=Math.hypot(mx,mz);mx/=l;mz/=l;const sp=run?11:6;p.x+=mx*sp*dt;p.z+=mz*sp*dt;let da=Math.atan2(mx,mz)-P.rotation.y;da=Math.atan2(Math.sin(da),Math.cos(da));P.rotation.y+=da*Math.min(1,dt*12);walk+=dt*(run?14:9);P.legs[0].rotation.x=Math.sin(walk)*.7;P.legs[1].rotation.x=-Math.sin(walk)*.7}else P.legs[0].rotation.x=P.legs[1].rotation.x=0;
 animar(P,(f||r)?(run?'run':'walk'):'idle');en=clamp(en+(run?-14:9)*dt,0,100);vy-=22*dt;p.y=Math.max(0,p.y+vy*dt);if(p.y==0)vy=0;
 COL.forEach(c=>{const dx=p.x-c.x,dz=p.z-c.z,d=Math.hypot(dx,dz),m=c.r+.5;if(d<m&&d>0){p.x=c.x+dx/d*m;p.z=c.z+dz/d*m}});const d=Math.hypot(p.x,p.z);if(d>64){p.x*=64/d;p.z*=64/d}}
/* ===== INICIO ===== */
const had=load();$('#nm').value=S.name;S.cols.forEach((c,i)=>$('#c'+i).value=c);$('#ac').value=S.acc;if(had)$('#go').textContent='Continuar aventura';
$('#cc').style.display='flex';rs();setP();loop(performance.now());
$('#go').onclick=()=>{au();S.name=$('#nm').value.trim()||'Valiente';sync();started=true;$('#cc').style.display='none';document.querySelectorAll('.hud').forEach(e=>e.style.display='block');$('#dock').style.display='flex';
 yaw=0;pit=.35;dist=9;hud();save();say('Sistema','Bienvenido/a a Valle... perdón, al Reino de Harmonía. Habla con las personas que tienen una «!» sobre la cabeza (tecla E).','#e9b949');setInterval(save,20000)};
